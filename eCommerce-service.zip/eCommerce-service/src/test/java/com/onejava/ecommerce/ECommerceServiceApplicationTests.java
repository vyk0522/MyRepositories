package com.onejava.ecommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ECommerceServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
